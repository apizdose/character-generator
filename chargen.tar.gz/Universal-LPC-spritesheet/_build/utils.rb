def die(message)
  STDERR.puts "ERROR: #{message}"
  exit 1
end