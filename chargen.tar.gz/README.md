Universal LPC Spritesheet Character Generator
=============================================

Based on [Universal LPC Spritesheet] (https://github.com/jrconway3/Universal-LPC-spritesheet).

Try it out at [gaurav.munjal.us] (http://gaurav.munjal.us/Universal-LPC-Spritesheet-Character-Generator).

### Status

New feature: I've just added previews of the actual animations. Oversize animations are still being worked on.

Please test and report issues. Contributions welcome!
